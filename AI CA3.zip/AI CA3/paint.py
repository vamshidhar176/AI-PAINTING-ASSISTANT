import streamlit as st
from PIL import Image, ImageFilter, ImageEnhance, ImageDraw, ImageFont
import requests
from io import BytesIO
import time
import random
import base64
import numpy as np

# ---------------------- Page Configuration ---------------------- #
st.set_page_config(page_title="🎨 AI Painting Assistant", layout="wide")
st.title("🎨 AI Painting Assistant")

# ---------------------- API Configuration ---------------------- #
# Hardcoded API key - replace with your actual Hugging Face API key
HF_API_KEY = "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"  # Replace with your actual API key

# ---------------------- Constants ---------------------- #

BRUSH_TYPES = ["Soft Round", "Hard Square", "Oil Paint", "Watercolor", "Sketch Pencil"]

COLOR_PALETTES = {
    "Dreamy": ["#FFB6C1", "#E6E6FA", "#ADD8E6", "#FFFACD"],
    "Vibrant": ["#FF4500", "#32CD32", "#1E90FF", "#FFD700"],
    "Dark Fantasy": ["#2F4F4F", "#8B0000", "#483D8B", "#4B0082"],
    "Autumn": ["#D2691E", "#8B4513", "#CD853F", "#F4A460", "#A0522D"],
    "Spring": ["#98FB98", "#00FA9A", "#00FF7F", "#3CB371", "#2E8B57"]
}

# Model selection options from Hugging Face
MODEL_OPTIONS = {
    "Stable Diffusion 2": "stabilityai/stable-diffusion-2",
    "Stable Diffusion XL": "stabilityai/stable-diffusion-xl-base-1.0",
    "Kandinsky 2.2": "kandinsky-community/kandinsky-2-2-decoder",
    "Playground v2": "playgroundai/playground-v2-1024px-aesthetic",
    "SDXL Lightning": "ByteDance/SDXL-Lightning",
    "OpenJourney v4": "prompthero/openjourney-v4",
    "Dreamshaper": "Lykon/dreamshaper-8",
    "Realistic Vision v5": "SG161222/Realistic_Vision_V5.0"
}

# ---------------------- Functions ---------------------- #

def generate_image_with_huggingface(prompt, negative_prompt, model_id):
    """Generate image using Hugging Face Inference API"""
    try:
        with st.spinner(f"🎨 Generating image with {model_id}... This might take a minute."):
            start_time = time.time()
            
            # API URL for the Hugging Face Inference API
            API_URL = f"https://api-inference.huggingface.co/models/{model_id}"
            
            # Prepare headers with hardcoded API key
            headers = {
                "Authorization": f"Bearer {HF_API_KEY}",
                "Content-Type": "application/json"
            }
            
            # Prepare payload
            payload = {
                "inputs": prompt,
                "parameters": {
                    "negative_prompt": negative_prompt,
                }
            }
            
            # Make the API request
            response = requests.post(API_URL, headers=headers, json=payload)
            
            # Check for errors
            if response.status_code != 200:
                st.error(f"Error from Hugging Face API: {response.status_code}")
                
                # Try to get more detailed error info
                try:
                    error_detail = response.json()
                    st.error(f"Error details: {error_detail}")
                except:
                    st.error(f"Response: {response.text}")
                return None
            else:
                # Process successful response
                image_bytes = response.content
                end_time = time.time()
                
                # Display the image
                image = Image.open(BytesIO(image_bytes))
                st.success(f"Image generated in {end_time - start_time:.2f} seconds!")
                return image
    
    except Exception as e:
        st.error(f"An error occurred: {str(e)}")
        return None

def generate_placeholder_image(width=512, height=512, text="AI Generated Art"):
    """Generate an artistic placeholder image when API is unavailable"""
    # Create a canvas with gradient background
    img = Image.new('RGB', (width, height), color=(240, 240, 240))
    draw = ImageDraw.Draw(img)
    
    # Create a gradient background
    for y in range(height):
        r = int(200 + (y / height) * 55)
        g = int(200 + (y / height) * 40)
        b = int(220 + (y / height) * 35)
        for x in range(width):
            draw.point((x, y), fill=(r, g, b))
    
    # Generate a more artistic pattern based on the text
    seed = sum(ord(c) for c in text) % 1000
    random.seed(seed)
    
    # Draw some flowing lines
    for _ in range(15):
        color = (
            random.randint(30, 200),
            random.randint(30, 200),
            random.randint(30, 200)
        )
        
        # Create bezier curve points
        points = []
        x = 0
        while x < width:
            points.append((x, random.randint(0, height)))
            x += random.randint(30, 100)
        
        # Draw the curve
        for i in range(len(points) - 1):
            draw.line([points[i], points[i+1]], fill=color, width=random.randint(1, 5))
    
    # Add some artistic circles
    for _ in range(20):
        color = (
            random.randint(50, 230),
            random.randint(50, 230),
            random.randint(50, 230),
        )
        size = random.randint(20, 100)
        x = random.randint(0, width - size)
        y = random.randint(0, height - size)
        opacity = random.randint(30, 150)
        
        # Create a temporary image for the circle with transparency
        circle_img = Image.new('RGBA', (width, height), color=(0, 0, 0, 0))
        circle_draw = ImageDraw.Draw(circle_img)
        circle_draw.ellipse([(x, y), (x + size, y + size)], fill=color + (opacity,))
        
        # Paste the circle onto the main image
        img = img.convert('RGBA')
        img = Image.alpha_composite(img, circle_img)
        img = img.convert('RGB')
        draw = ImageDraw.Draw(img)
    
    # Add text label
    try:
        # Try to load a font, fall back to default if not available
        try:
            font = ImageFont.truetype("arial.ttf", 20)
        except:
            font = ImageFont.load_default()
            
        # Draw text with shadow for better visibility
        text_width = font.getbbox(text)[2]
        x_position = (width - text_width) // 2
        y_position = height - 40
        
        # Draw shadow first
        draw.text((x_position+2, y_position+2), text, fill=(0, 0, 0), font=font)
        # Draw main text
        draw.text((x_position, y_position), text, fill=(255, 255, 255), font=font)
    except:
        # Fallback if font operations fail
        draw.text((width//2-100, height-40), text, fill=(255, 255, 255))
    
    return img

def create_generative_art(width=512, height=512, complexity=5, color_theme="Vibrant"):
    """Create procedurally generated artwork based on parameters"""
    # Start with a blank canvas
    img = Image.new('RGB', (width, height), color=(240, 240, 240))
    draw = ImageDraw.Draw(img)
    
    # Get color palette
    palette = COLOR_PALETTES.get(color_theme, COLOR_PALETTES["Vibrant"])
    
    # Draw background gradient
    for y in range(height):
        r = int(220 + (y / height) * 35)
        g = int(220 + (y / height) * 35)
        b = int(220 + (y / height) * 35)
        for x in range(width):
            draw.point((x, y), fill=(r, g, b))
    
    # Generate art based on complexity (1-10)
    num_elements = complexity * 20
    
    # Set random seed for reproducibility
    random.seed(hash(color_theme) % 1000 + complexity)
    
    # Draw background shapes
    for _ in range(num_elements // 2):
        color = random.choice(palette)
        shape_size = random.randint(50, 200)
        x = random.randint(-50, width)
        y = random.randint(-50, height)
        opacity = random.randint(30, 150)
        
        # Create a temporary image for the shape with transparency
        shape_img = Image.new('RGBA', (width, height), color=(0, 0, 0, 0))
        shape_draw = ImageDraw.Draw(shape_img)
        
        # Choose a random shape type
        shape_type = random.choice(['circle', 'rectangle', 'triangle'])
        
        if shape_type == 'circle':
            shape_draw.ellipse([(x, y), (x + shape_size, y + shape_size)], 
                              fill=color + (opacity,))
        elif shape_type == 'rectangle':
            shape_draw.rectangle([(x, y), (x + shape_size, y + shape_size)], 
                                fill=color + (opacity,))
        else:  # triangle
            shape_draw.polygon([(x, y + shape_size), 
                              (x + shape_size, y + shape_size), 
                              (x + shape_size // 2, y)], 
                             fill=color + (opacity,))
        
        # Paste the shape onto the main image
        img = img.convert('RGBA')
        img = Image.alpha_composite(img, shape_img)
    
    # Add detail elements
    for _ in range(num_elements // 2):
        color = random.choice(palette)
        x1 = random.randint(0, width)
        y1 = random.randint(0, height)
        x2 = x1 + random.randint(-200, 200)
        y2 = y1 + random.randint(-200, 200)
        
        # Create lines of varying thickness
        line_width = random.randint(1, 3)
        draw = ImageDraw.Draw(img)
        draw.line([(x1, y1), (x2, y2)], fill=color, width=line_width)
    
    # Apply some filters
    img = img.filter(ImageFilter.GaussianBlur(1))
    img = ImageEnhance.Contrast(img).enhance(1.2)
    
    return img.convert('RGB')

def style_transfer(content_image, style_strength=0.3):
    """Apply a simple style transfer effect"""
    # Apply some filters as a basic style transfer simulation
    enhanced = ImageEnhance.Contrast(content_image).enhance(1.2)
    enhanced = ImageEnhance.Color(enhanced).enhance(1.5)
    styled = enhanced.filter(ImageFilter.CONTOUR)
    blended = Image.blend(content_image, styled, alpha=style_strength)
    return blended

def recommend_brush(theme):
    """Suggest a brush based on theme"""
    theme_lower = theme.lower()
    if "fantasy" in theme_lower:
        return random.choice(["Oil Paint", "Watercolor"])
    elif "nature" in theme_lower:
        return random.choice(["Soft Round", "Watercolor"])
    elif "portrait" in theme_lower:
        return random.choice(["Soft Round", "Sketch Pencil"])
    else:
        return random.choice(BRUSH_TYPES)

def suggest_palette(mood):
    return COLOR_PALETTES.get(mood, COLOR_PALETTES["Dreamy"])

def smart_autocomplete(sketch_image):
    """Enhance a sketch with AI assistance"""
    # Apply a series of filters to simulate AI enhancement
    enhanced = sketch_image.filter(ImageFilter.DETAIL)
    enhanced = enhanced.filter(ImageFilter.SMOOTH_MORE)
    enhanced = ImageEnhance.Contrast(enhanced).enhance(1.3)
    return enhanced

def add_layer(base_image, new_layer_image):
    """Combine two image layers"""
    # Resize the new layer to match the base if needed
    new_layer_resized = new_layer_image.resize(base_image.size)
    
    # Ensure both images have alpha channel
    if base_image.mode != 'RGBA':
        base_image = base_image.convert('RGBA')
    if new_layer_resized.mode != 'RGBA':
        new_layer_resized = new_layer_resized.convert('RGBA')
    
    # Create a new blank image with alpha
    result = Image.new('RGBA', base_image.size, (0, 0, 0, 0))
    
    # Paste the base image
    result.paste(base_image, (0, 0))
    
    # Paste the new layer on top
    result.paste(new_layer_resized, (0, 0), new_layer_resized)
    
    return result

def get_image_download_link(img, filename="artwork.png", text="Download Image"):
    """Generate a link to download the image"""
    buffered = BytesIO()
    img.save(buffered, format="PNG")
    img_str = base64.b64encode(buffered.getvalue()).decode()
    href = f'<a href="data:image/png;base64,{img_str}" download="{filename}">{text}</a>'
    return href

# ---------------------- Streamlit UI ---------------------- #

# Store generated images in session state for downloading
if 'generated_image' not in st.session_state:
    st.session_state.generated_image = None

# Menu selection
menu = st.sidebar.selectbox(
    "Select a feature", 
    ("AI Image Generation", "Model Tester", "Procedural Art Generator", 
     "Style Transfer", "Brush Suggestion", "Color Palette Suggestion", 
     "Smart Auto-Complete", "Layer Management")
)

# Main content based on selected menu
if menu == "AI Image Generation":
    st.subheader("Generate Art with AI")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        selected_model = st.selectbox("Select Model", list(MODEL_OPTIONS.keys()))
        model_id = MODEL_OPTIONS[selected_model]
        
        prompt = st.text_area("Enter your prompt:", height=100, 
                            placeholder="Example: A serene landscape with mountains and a lake at sunset, digital art style")
        
        negative_prompt = st.text_area("Negative prompt (things to avoid):", 
                                     value="blurry, distorted, low quality, ugly, bad anatomy",
                                     height=68)
    
    with col2:
        st.write("**Tips for better prompts:**")
        st.write("- Be specific about style (e.g., watercolor, oil painting)")
        st.write("- Mention lighting and mood")
        st.write("- Include color references")
        st.write("**About this model:**")
        st.write(f"Model ID: {model_id}")
        st.write(f"[View on Hugging Face](https://huggingface.co/{model_id})")
    
    if st.button("Generate Image"):
        if prompt:
            # Use Hugging Face API
            img = generate_image_with_huggingface(prompt, negative_prompt, model_id)
            if img:
                st.session_state.generated_image = img
                st.image(img, caption=f"Generated by {selected_model}", use_container_width=True)
                st.markdown(get_image_download_link(img, f"{selected_model.replace(' ', '_')}_image.png"), unsafe_allow_html=True)
        else:
            st.warning("Please enter a prompt first")

elif menu == "Model Tester":
    st.subheader("Test Different Hugging Face Models")
    
    # Model selection
    selected_model = st.selectbox("Select Model to Test", list(MODEL_OPTIONS.keys()))
    model_id = MODEL_OPTIONS[selected_model]
    
    # Model information
    st.write(f"**Model ID**: {model_id}")
    st.write(f"**Hugging Face Page**: [View Model on Hugging Face](https://huggingface.co/{model_id})")
    
    # Prompt inputs
    col1, col2 = st.columns(2)
    
    with col1:
        prompt = st.text_area("Enter a prompt for image generation:", 
                             value="A beautiful sunset over mountains, high quality, detailed",
                             height=100)
    
    with col2:
        negative_prompt = st.text_area("Negative prompt (things to avoid):", 
                                       value="blurry, distorted, low quality, ugly, bad anatomy",
                                       height=100)
    
    # Generate button
    if st.button("Generate Test Image"):
        if prompt:
            img = generate_image_with_huggingface(prompt, negative_prompt, model_id)
            if img:
                st.session_state.generated_image = img
                st.image(img, caption=f"Generated by {selected_model}", use_container_width=True)
                
                # Add a download button
                buffered = BytesIO()
                img.save(buffered, format="PNG")
                st.download_button(
                    label="Download Image",
                    data=buffered.getvalue(),
                    file_name=f"{selected_model.replace(' ', '_')}_image.png",
                    mime="image/png"
                )

elif menu == "Procedural Art Generator":
    st.subheader("Generate Art Programmatically")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        complexity = st.slider("Complexity", min_value=1, max_value=10, value=5)
        color_theme = st.selectbox("Color Theme", list(COLOR_PALETTES.keys()))
        width = st.slider("Width", min_value=256, max_value=1024, value=512, step=64)
        height = st.slider("Height", min_value=256, max_value=1024, value=512, step=64)
    
    with col2:
        st.write("**About Procedural Art:**")
        st.write("This feature creates unique abstract art based on mathematical algorithms.")
        st.write("Higher complexity means more elements and details.")
        st.write("Each color theme creates a different mood and style.")
    
    if st.button("Generate Art"):
        img = create_generative_art(width, height, complexity, color_theme)
        st.session_state.generated_image = img
        st.image(img, caption="Generated Artwork", use_container_width=True)
        st.markdown(get_image_download_link(img, "procedural_art.png"), unsafe_allow_html=True)

elif menu == "Style Transfer":
    st.subheader("Apply Artistic Style")
    
    uploaded_file = st.file_uploader("Upload your artwork", type=["png", "jpg", "jpeg"])
    
    if uploaded_file:
        img = Image.open(uploaded_file)
        st.image(img, caption="Original Image", use_container_width=True)
        
        style_strength = st.slider("Style Strength", min_value=0.1, max_value=1.0, value=0.3, step=0.1)
        
        if st.button("Apply Style"):
            styled_img = style_transfer(img, style_strength)
            st.session_state.generated_image = styled_img
            st.image(styled_img, caption="Styled Artwork", use_container_width=True)
            st.markdown(get_image_download_link(styled_img, "styled_artwork.png"), unsafe_allow_html=True)

elif menu == "Brush Suggestion":
    st.subheader("Get Brush Recommendations")
    
    theme = st.text_input("Enter the theme (e.g., fantasy, nature, portrait):")
    if st.button("Suggest Brush"):
        if theme:
            brush = recommend_brush(theme)
            st.success(f"Recommended Brush: {brush}")
            st.write("This brush type would work well for your theme based on traditional painting techniques.")
        else:
            st.warning("Please enter a theme first")

elif menu == "Color Palette Suggestion":
    st.subheader("Get Color Palette Ideas")
    
    mood = st.selectbox("Choose Mood", list(COLOR_PALETTES.keys()))
    if st.button("Suggest Palette"):
        palette = suggest_palette(mood)
        st.write("Suggested Colors:")
        
        # Display colors with their hex values
        cols = st.columns(len(palette))
        for i, color in enumerate(palette):
            with cols[i]:
                st.markdown(f"<div style='background-color:{color};height:50px;border-radius:5px;'></div>", unsafe_allow_html=True)
                st.write(color)

elif menu == "Smart Auto-Complete":
    st.subheader("Enhance Your Sketches")
    
    uploaded_sketch = st.file_uploader("Upload your sketch", type=["png", "jpg", "jpeg"])
    if uploaded_sketch:
        sketch = Image.open(uploaded_sketch)
        st.image(sketch, caption="Original Sketch", use_container_width=True)
        
        if st.button("Enhance Sketch"):
            completed = smart_autocomplete(sketch)
            st.session_state.generated_image = completed
            st.image(completed, caption="AI Enhanced Sketch", use_container_width=True)
            st.markdown(get_image_download_link(completed, "enhanced_sketch.png"), unsafe_allow_html=True)

elif menu == "Layer Management":
    st.subheader("Combine Image Layers")
    
    col1, col2 = st.columns(2)
    
    with col1:
        base_file = st.file_uploader("Upload Base Layer", type=["png", "jpg", "jpeg"], key="base")
        if base_file:
            base_img = Image.open(base_file)
            st.image(base_img, caption="Base Layer", use_container_width=True)
    
    with col2:
        new_layer_file = st.file_uploader("Upload New Layer", type=["png", "jpg", "jpeg"], key="layer")
        if new_layer_file:
            new_layer_img = Image.open(new_layer_file)
            st.image(new_layer_img, caption="New Layer", use_container_width=True)
    
    if base_file and new_layer_file:
        if st.button("Combine Layers"):
            final_img = add_layer(base_img, new_layer_img)
            st.session_state.generated_image = final_img
            st.image(final_img, caption="Combined Layers", use_container_width=True)
            st.markdown(get_image_download_link(final_img, "combined_layers.png"), unsafe_allow_html=True)

# Add instructions expander
with st.sidebar.expander("Instructions & Tips"):
    st.markdown("""
    ### How to use this app
    
    1. Select a feature from the sidebar menu
    2. Follow the instructions for each tool
    
    ### Tips for AI Image Generation
    
    * Be specific in your prompts
    * Use descriptive adjectives
    * Include style references
    * Use negative prompts to avoid unwanted elements
    
    ### About Models
    
    Different models excel at different styles:
    * Stable Diffusion XL - High quality general purpose
    * Realistic Vision - Photorealistic images
    * Dreamshaper - Creative and artistic styles
    * OpenJourney - Midjourney-like aesthetics
    """)

# Add a footer
st.markdown("---")
st.markdown("AI Painting Assistant - Your digital creative partner")